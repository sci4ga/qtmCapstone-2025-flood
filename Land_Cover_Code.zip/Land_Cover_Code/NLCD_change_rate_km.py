import os
import pandas as pd
import glob

def load_county():
    
    pattern = os.path.join(".", "*.csv")
    csv_files = glob.glob(pattern)

    county_data ={}

    for file in csv_files:
        name = os.path.splitext(os.path.basename(file))[0]
        df = pd.read_csv(file)
        county_data[name] = df

    return county_data

def calculate_rate(county_data):
    type_map = {
    "developed high intensity": "developed sites",
    "developed low intensity": "developed sites",
    "developed medium intensity": "developed sites",
    "developed open space": "developed sites",

    "deciduous forest": "forest",
    "evergreen forest": "forest",
    "mixed forest": "forest",

    "emergent herbaceous wetlands": "wetland",
    "woody wetlands": "wetland",

    "open water": "open water",
    "barren land (rock/sand/clay)": "barren land (rock/sand/clay)",
    "cultivated crops": "cultivated crops",
    "grasslands/herbaceous": "grasslands/herbaceous",
    "pasture/hay": "pasture/hay",
    "shrub/shrub": "shrub/shrub"
    }



    rate_change_dict = {}
   

    for county, df in county_data.items():
    
        df_data = df.iloc[1:]

        original_types = df_data.iloc[:,0].astype(str).str.strip().str.lower()
        new_types = original_types.map(type_map)
        y1996 = pd.to_numeric(df_data.iloc[:,12],errors = 'raise')
        y2023 = pd.to_numeric(df_data.iloc[:,-2],errors = 'raise')
    
        temp_df = pd.DataFrame({
            'new_type': new_types,
            'y1996': y1996,
            'y2023': y2023
        })

        grouped = temp_df.groupby('new_type').sum()
        grouped['rate_change'] = (grouped['y2023'] - grouped['y1996']) / grouped['y1996'].replace(0, pd.NA)

        rate_change_dict[county] = grouped['rate_change']
    
    grouped_rate_change_NLCD = pd.DataFrame(rate_change_dict)

    grouped_rate_change_NLCD.to_csv(os.path.join(".", "grouped_rate_change_NLCD.csv"))

    return grouped_rate_change_NLCD

if __name__ == "__main__":
   
   county_data = load_county()

   grouped_rate_change_NLCD = calculate_rate(county_data)

   print("processed")


